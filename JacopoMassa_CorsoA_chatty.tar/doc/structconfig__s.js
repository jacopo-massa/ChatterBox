var structconfig__s =
[
    [ "DirName", "structconfig__s.html#a2cdf18427f853ac237c4131387771716", null ],
    [ "MaxConnections", "structconfig__s.html#a57316191b3c430a9f0242cf14744fe3f", null ],
    [ "MaxFileSize", "structconfig__s.html#a58d5f56cf33d2c86c16ad09f6d97b96a", null ],
    [ "MaxHistMsgs", "structconfig__s.html#a4918ac4b7b476dd5a3c6edbd6404a52b", null ],
    [ "MaxMsgSize", "structconfig__s.html#a6a522c6bd8d4c851fe7a1714f9baba83", null ],
    [ "StatFileName", "structconfig__s.html#ac8b8d1f02a9cb116cce651cde1444fd8", null ],
    [ "ThreadsInPool", "structconfig__s.html#ae570dfc9bd511f67f44e2f8a5f9692a4", null ],
    [ "UnixPath", "structconfig__s.html#a0cd4128a7e1c25a4735d4f55e5f1ca08", null ]
];