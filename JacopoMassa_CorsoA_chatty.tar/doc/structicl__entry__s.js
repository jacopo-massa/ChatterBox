var structicl__entry__s =
[
    [ "fd", "structicl__entry__s.html#a5e93acca0b720e689ad08b65e7f37ec7", null ],
    [ "key", "structicl__entry__s.html#a175ddfefe49a8f6fa16155e58c39c88e", null ],
    [ "next", "structicl__entry__s.html#af5bc67953f51e75cf74066d616f3420c", null ],
    [ "online", "structicl__entry__s.html#af419df47afbc98885b0299b051ab8a7e", null ],
    [ "queue", "structicl__entry__s.html#a73dc685870a737943103e192077777b9", null ]
];