var ops_8h =
[
    [ "op_t", "ops_8h.html#ac6fa1b34da8872e34c2936391332f44c", [
      [ "REGISTER_OP", "ops_8h.html#ac6fa1b34da8872e34c2936391332f44caf36690799901b259e0db234a04fc2969", null ],
      [ "CONNECT_OP", "ops_8h.html#ac6fa1b34da8872e34c2936391332f44cab602ddf0795d3c4dc2fd0b4b957ba988", null ],
      [ "POSTTXT_OP", "ops_8h.html#ac6fa1b34da8872e34c2936391332f44ca87576ba07c1cfb86b898b212bf927e3b", null ],
      [ "POSTTXTALL_OP", "ops_8h.html#ac6fa1b34da8872e34c2936391332f44cad8bffd524142ec0c418a426344387282", null ],
      [ "POSTFILE_OP", "ops_8h.html#ac6fa1b34da8872e34c2936391332f44caf2b9ae66799c6fdfc938b69f49c9d4e4", null ],
      [ "GETFILE_OP", "ops_8h.html#ac6fa1b34da8872e34c2936391332f44cadb9dcac2886dea585d6851db2a02de4b", null ],
      [ "GETPREVMSGS_OP", "ops_8h.html#ac6fa1b34da8872e34c2936391332f44cad40f98fc799cf8b6a8dc25c90464a809", null ],
      [ "USRLIST_OP", "ops_8h.html#ac6fa1b34da8872e34c2936391332f44ca76c5f8cf5dd046fbfe3f0b6a7bce8e90", null ],
      [ "UNREGISTER_OP", "ops_8h.html#ac6fa1b34da8872e34c2936391332f44cabc2ab44946aad99a4cda3f0e4abb5b5a", null ],
      [ "DISCONNECT_OP", "ops_8h.html#ac6fa1b34da8872e34c2936391332f44ca06d81ab3ef58420bbebac2c67dc901e2", null ],
      [ "CREATEGROUP_OP", "ops_8h.html#ac6fa1b34da8872e34c2936391332f44ca30840713ad9050c2d275b31ff8404313", null ],
      [ "ADDGROUP_OP", "ops_8h.html#ac6fa1b34da8872e34c2936391332f44ca30f53d46265f83a2b0a14d6486a450d5", null ],
      [ "DELGROUP_OP", "ops_8h.html#ac6fa1b34da8872e34c2936391332f44cab9abe0fa4dab90183a19f2f56dfe0d49", null ],
      [ "OP_OK", "ops_8h.html#ac6fa1b34da8872e34c2936391332f44cacc156be86a1cb4bfc0e21d8c72e4971c", null ],
      [ "TXT_MESSAGE", "ops_8h.html#ac6fa1b34da8872e34c2936391332f44cae8592a49ed69355669ec14cdb03291ea", null ],
      [ "FILE_MESSAGE", "ops_8h.html#ac6fa1b34da8872e34c2936391332f44ca114675ea37d79ff22f18645a7ba2dc73", null ],
      [ "OP_FAIL", "ops_8h.html#ac6fa1b34da8872e34c2936391332f44cadad4289276b97b650558ce66d141d648", null ],
      [ "OP_NICK_ALREADY", "ops_8h.html#ac6fa1b34da8872e34c2936391332f44ca81c2903af74ab2d9f41295295ebdf818", null ],
      [ "OP_NICK_UNKNOWN", "ops_8h.html#ac6fa1b34da8872e34c2936391332f44ca460bac3ab18774fdad96a60256f5f58b", null ],
      [ "OP_MSG_TOOLONG", "ops_8h.html#ac6fa1b34da8872e34c2936391332f44ca020f2a80f521804e41b46c6f994ec72f", null ],
      [ "OP_NO_SUCH_FILE", "ops_8h.html#ac6fa1b34da8872e34c2936391332f44ca1f7fb97bf4bf19858a8805313eca2ae2", null ],
      [ "OP_END", "ops_8h.html#ac6fa1b34da8872e34c2936391332f44ca010acee11f1e0ca0026e20c2f36bfdb7", null ]
    ] ]
];