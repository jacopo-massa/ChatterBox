var structoperation__t =
[
    [ "msg", "structoperation__t.html#a3034fb2b256feb05ef6d4d034cb17265", null ],
    [ "n", "structoperation__t.html#aa18a74143d24d04171d8b8206ae9d15b", null ],
    [ "op", "structoperation__t.html#afa66e43cb50d2792e12f7a2b054bc396", null ],
    [ "rname", "structoperation__t.html#a6889a2b00ba2ad2d34666eea3d59e736", null ],
    [ "size", "structoperation__t.html#a453c2473442f61fbc268d30c8ebb4338", null ],
    [ "sname", "structoperation__t.html#a7822f225cfc9123dab423ba683c1aace", null ]
];