var connections_8h =
[
    [ "MAX_RETRIES", "connections_8h.html#aecf13b8dc783db2202ca5c34fe117fc3", null ],
    [ "MAX_SLEEPING", "connections_8h.html#a763a071b50fb9cf7997861d0f5266387", null ],
    [ "UNIX_PATH_MAX", "connections_8h.html#a7baab2aa5bf8eb14b6128e0f16634837", null ],
    [ "openConnection", "connections_8h.html#a93ad31c416b2e2055827e5f684e89daf", null ],
    [ "readData", "connections_8h.html#acf5cb8379636265d11a008d6aa94dc30", null ],
    [ "readHeader", "connections_8h.html#a2a15cc3debfd6700ea0f40a198c55c85", null ],
    [ "readMsg", "connections_8h.html#a2fc6b845d44636fb241a848e58c83420", null ],
    [ "sendData", "connections_8h.html#a7812cf59eeeaa63ce7d7b9ce93125462", null ],
    [ "sendHeader", "connections_8h.html#a76519996d7c1c002a8214e8ba40af51c", null ],
    [ "sendRequest", "connections_8h.html#a3c23eb25de2ae8b5216eb6dd847521c0", null ]
];