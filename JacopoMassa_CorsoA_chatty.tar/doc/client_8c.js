var client_8c =
[
    [ "operation_t", "structoperation__t.html", "structoperation__t" ],
    [ "_POSIX_C_SOURCE", "client_8c.html#a3024ccd4a9af5109d24e6c57565d74a1", null ],
    [ "main", "client_8c.html#a0ddf1224851353fc92bfbff6f499fa97", null ]
];