var threadpool_8h =
[
    [ "threadpool_task_s", "structthreadpool__task__s.html", "structthreadpool__task__s" ],
    [ "threadpool_s", "structthreadpool__s.html", "structthreadpool__s" ],
    [ "MAX_QUEUE", "threadpool_8h.html#ab94814559b67e4a2a564087f821145ea", null ],
    [ "MAX_THREADS", "threadpool_8h.html#a8b5173357adb02a86c027316e0acdfa0", null ],
    [ "threadpool_error_t", "threadpool_8h.html#ae068ff0d1c12ba259d41adef22ed06b8", null ],
    [ "threadpool_shutdown_t", "threadpool_8h.html#afd6ec4fe76fab223eac5a28688bacd45", null ],
    [ "threadpool_t", "threadpool_8h.html#afb23d9f1de34f6180b97f14954bf8c4d", null ],
    [ "threadpool_task_t", "threadpool_8h.html#a148a397babfc6ccbd620c78532b50a9f", null ],
    [ "threadpool_destroy_flags_t", "threadpool_8h.html#a251d951c146fc30ef7d50fdd07e5592f", [
      [ "threadpool_graceful", "threadpool_8h.html#a251d951c146fc30ef7d50fdd07e5592fa47d8b16b2a2e13ad84fd678fd7720d85", null ]
    ] ],
    [ "threadpool_error_s", "threadpool_8h.html#a7f231644609b4e5c852f35bf6e697deb", [
      [ "threadpool_invalid", "threadpool_8h.html#a7f231644609b4e5c852f35bf6e697deba23d5a8959daf5de5f66098a3198d907b", null ],
      [ "threadpool_lock_failure", "threadpool_8h.html#a7f231644609b4e5c852f35bf6e697deba561ad2293f0fceae47dac28babf3c012", null ],
      [ "threadpool_queue_full", "threadpool_8h.html#a7f231644609b4e5c852f35bf6e697debabda3787fb0868847e27a3f4f4755def5", null ],
      [ "threadpool_shutdown", "threadpool_8h.html#a7f231644609b4e5c852f35bf6e697debaa2024ae2b243c037f07edf80c0a12311", null ],
      [ "threadpool_thread_failure", "threadpool_8h.html#a7f231644609b4e5c852f35bf6e697deba385969d03ee20f2af1b727310f736e6e", null ]
    ] ],
    [ "threadpool_shutdown_s", "threadpool_8h.html#a57df7f50d2fcada8b393c358d5a02288", [
      [ "immediate_shutdown", "threadpool_8h.html#a57df7f50d2fcada8b393c358d5a02288a876f350433b986fed4294a9f88226de0", null ],
      [ "graceful_shutdown", "threadpool_8h.html#a57df7f50d2fcada8b393c358d5a02288a74750b520697e8caeec8c10661e1476e", null ]
    ] ],
    [ "threadpool_add", "threadpool_8h.html#a4c6afcf54333367966ce752c87c31c8e", null ],
    [ "threadpool_create", "threadpool_8h.html#ae66d2014a082989787e6788f1e7239df", null ],
    [ "threadpool_destroy", "threadpool_8h.html#a6e0fb9f453fdb75a704d8e7c957fef15", null ],
    [ "threadpool_free", "threadpool_8h.html#a756e7304c19d3ef5e1c66788f7ff0f5f", null ]
];