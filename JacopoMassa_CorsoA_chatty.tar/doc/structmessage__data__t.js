var structmessage__data__t =
[
    [ "buf", "structmessage__data__t.html#aba52694fd59a6cf8227b84b3cd1c30dd", null ],
    [ "hdr", "structmessage__data__t.html#a45328b402174241b93bcefcdceca4545", null ]
];