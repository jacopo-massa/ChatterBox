var structmessage__t =
[
    [ "data", "structmessage__t.html#a4246f40b480c7d84ff6319ef2ae7b305", null ],
    [ "hdr", "structmessage__t.html#a6c9e3c76c26fd15afd27fca633875978", null ]
];