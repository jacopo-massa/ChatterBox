var structthreadpool__s =
[
    [ "count", "structthreadpool__s.html#af955d9621f131b8ad6cc0a6698b45512", null ],
    [ "head", "structthreadpool__s.html#a0841df35464c90790fe3f0c04ea10776", null ],
    [ "lock", "structthreadpool__s.html#a19aeedf36e83f47fa53413ac50b2247d", null ],
    [ "notify", "structthreadpool__s.html#aa24833f8a9b60ee06507a68ab0fce54e", null ],
    [ "queue", "structthreadpool__s.html#a14895c3e887b4d01376700ce3a99d56a", null ],
    [ "queue_size", "structthreadpool__s.html#a2f46f7caccb34afc81a82aa2d61fc1ba", null ],
    [ "shutdown", "structthreadpool__s.html#a90c0515826c97da9db4fb6b3b8181c07", null ],
    [ "started", "structthreadpool__s.html#af8a847d3793e818d3700f9aa0bb0c9b8", null ],
    [ "tail", "structthreadpool__s.html#aee69fa052616197f5fa176fda8e1447d", null ],
    [ "thread_count", "structthreadpool__s.html#a7c36217d024cc5f9d4d21a8472003328", null ],
    [ "threads", "structthreadpool__s.html#a2ae433e00c33ec8b296a4d746193e4e6", null ]
];