var files_dup =
[
    [ "cmake-build-debug", "dir_95e29a8b8ee7c54052c171a88bb95675.html", "dir_95e29a8b8ee7c54052c171a88bb95675" ],
    [ "chatty.c", "chatty_8c.html", "chatty_8c" ],
    [ "client.c", "client_8c.html", "client_8c" ],
    [ "config.h", "config_8h.html", "config_8h" ],
    [ "connections.c", "connections_8c.html", "connections_8c" ],
    [ "connections.h", "connections_8h.html", "connections_8h" ],
    [ "icl_hash.c", "icl__hash_8c.html", "icl__hash_8c" ],
    [ "icl_hash.h", "icl__hash_8h.html", "icl__hash_8h" ],
    [ "message.h", "message_8h.html", "message_8h" ],
    [ "ops.h", "ops_8h.html", "ops_8h" ],
    [ "queue.c", "queue_8c.html", "queue_8c" ],
    [ "queue.h", "queue_8h.html", "queue_8h" ],
    [ "stats.h", "stats_8h.html", "stats_8h" ],
    [ "threadpool.c", "threadpool_8c.html", "threadpool_8c" ],
    [ "threadpool.h", "threadpool_8h.html", "threadpool_8h" ],
    [ "utility.c", "utility_8c.html", "utility_8c" ],
    [ "utility.h", "utility_8h.html", "utility_8h" ]
];