var searchData=
[
  ['getfile',['getFile',['../chatty_8c.html#a0539bd764b45ad55a0528c0561e0c664',1,'getFile(long fd, message_t msg):&#160;chatty.c'],['../chatty_8h.html#a0539bd764b45ad55a0528c0561e0c664',1,'getFile(long fd, message_t msg):&#160;chatty.c']]],
  ['getfile_5fop',['GETFILE_OP',['../ops_8h.html#ac6fa1b34da8872e34c2936391332f44cadb9dcac2886dea585d6851db2a02de4b',1,'ops.h']]],
  ['getprevmsgs',['getPrevMSGS',['../chatty_8c.html#a2cfeac572e621db4689289676b5030ba',1,'getPrevMSGS(long fd, message_t msg):&#160;chatty.c'],['../chatty_8h.html#a2cfeac572e621db4689289676b5030ba',1,'getPrevMSGS(long fd, message_t msg):&#160;chatty.c']]],
  ['getprevmsgs_5fop',['GETPREVMSGS_OP',['../ops_8h.html#ac6fa1b34da8872e34c2936391332f44cad40f98fc799cf8b6a8dc25c90464a809',1,'ops.h']]],
  ['graceful_5fshutdown',['graceful_shutdown',['../threadpool_8h.html#a57df7f50d2fcada8b393c358d5a02288a74750b520697e8caeec8c10661e1476e',1,'threadpool.h']]]
];
