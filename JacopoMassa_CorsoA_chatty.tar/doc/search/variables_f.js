var searchData=
[
  ['unixpath',['UnixPath',['../structconfig__s.html#ab13f2c10dc85ac86a157ab17f7559e9f',1,'config_s']]],
  ['users',['users',['../chatty_8c.html#acb748f6c78847d13af1bf7ee34b66b66',1,'chatty.c']]]
];
