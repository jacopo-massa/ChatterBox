var searchData=
[
  ['senddata',['sendData',['../connections_8c.html#a7812cf59eeeaa63ce7d7b9ce93125462',1,'sendData(long fd, message_data_t *msg):&#160;connections.c'],['../connections_8h.html#a7812cf59eeeaa63ce7d7b9ce93125462',1,'sendData(long fd, message_data_t *msg):&#160;connections.c']]],
  ['sender',['sender',['../structmessage__hdr__t.html#a6aa18d82629c912fe68c229936b87c77',1,'message_hdr_t']]],
  ['sendheader',['sendHeader',['../connections_8c.html#a1a3f1d447f26575379802386e4cb1587',1,'sendHeader(long fd, message_hdr_t *msg):&#160;connections.c'],['../connections_8h.html#a76519996d7c1c002a8214e8ba40af51c',1,'sendHeader(long fd, message_hdr_t *hdr):&#160;connections.c']]],
  ['sendrequest',['sendRequest',['../connections_8c.html#a3c23eb25de2ae8b5216eb6dd847521c0',1,'sendRequest(long fd, message_t *msg):&#160;connections.c'],['../connections_8h.html#a3c23eb25de2ae8b5216eb6dd847521c0',1,'sendRequest(long fd, message_t *msg):&#160;connections.c']]],
  ['shutdown',['shutdown',['../structthreadpool__s.html#a5161d377a61befc3f8103e794d5cb582',1,'threadpool_s']]],
  ['sig_5fmanager',['sig_manager',['../chatty_8c.html#a975f38bd605bebfa6bb8b899d30457fb',1,'chatty.c']]],
  ['sig_5fmanager_5ffunction',['sig_manager_function',['../chatty_8c.html#adbb76f80add0caf84c50ad53813fced7',1,'sig_manager_function(void *sigset):&#160;chatty.c'],['../chatty_8h.html#adbb76f80add0caf84c50ad53813fced7',1,'sig_manager_function(void *sigset):&#160;chatty.c']]],
  ['size',['size',['../structoperation__t.html#a37363161b41c4165b98cba7abc7a9d95',1,'operation_t']]],
  ['sname',['sname',['../structoperation__t.html#a596940e8f95dfc43bb298b5e8148c770',1,'operation_t']]],
  ['started',['started',['../structthreadpool__s.html#abfafc640452d742a5a404a158ce4737a',1,'threadpool_s']]],
  ['statfilename',['StatFileName',['../structconfig__s.html#a76aa48db65fcc5da8f8cecc5eff66104',1,'config_s']]],
  ['statistics',['statistics',['../structstatistics.html',1,'']]],
  ['stats_2eh',['stats.h',['../stats_8h.html',1,'']]],
  ['syscall',['SYSCALL',['../utility_8h.html#a490c51c408053e3ddf85a8bd672789d2',1,'utility.h']]]
];
