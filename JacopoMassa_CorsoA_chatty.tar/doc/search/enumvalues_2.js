var searchData=
[
  ['delgroup_5fop',['DELGROUP_OP',['../ops_8h.html#ac6fa1b34da8872e34c2936391332f44cab9abe0fa4dab90183a19f2f56dfe0d49',1,'ops.h']]],
  ['disconnect_5fop',['DISCONNECT_OP',['../ops_8h.html#ac6fa1b34da8872e34c2936391332f44ca06d81ab3ef58420bbebac2c67dc901e2',1,'ops.h']]]
];
