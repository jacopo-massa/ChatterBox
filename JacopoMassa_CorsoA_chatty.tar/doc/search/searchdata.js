var indexSectionsWithContent =
{
  0: "_abcdefghiklmnopqrstu",
  1: "cimnoqst",
  2: "cimoqstu",
  3: "cdgilmopqrstu",
  4: "abcdfhklmnoqrstu",
  5: "cimnqt",
  6: "ot",
  7: "acdfgioprtu",
  8: "_bdehlmostu",
  9: "d"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "pages"
};

var indexSectionLabels =
{
  0: "Tutto",
  1: "Strutture dati",
  2: "File",
  3: "Funzioni",
  4: "Variabili",
  5: "Ridefinizioni di tipo (typedef)",
  6: "Tipi enumerati (enum)",
  7: "Valori del tipo enumerato",
  8: "Definizioni",
  9: "Pagine"
};

