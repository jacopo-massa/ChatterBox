var searchData=
[
  ['listener_5ffunction',['listener_function',['../chatty_8c.html#a0ebab961785c65f54fa4a8b18991cfbb',1,'listener_function(void *connfd):&#160;chatty.c'],['../chatty_8h.html#a0ebab961785c65f54fa4a8b18991cfbb',1,'listener_function(void *connfd):&#160;chatty.c']]]
];
