var searchData=
[
  ['threadpool_5fs',['threadpool_s',['../structthreadpool__s.html',1,'']]],
  ['threadpool_5ftask_5fs',['threadpool_task_s',['../structthreadpool__task__s.html',1,'']]]
];
