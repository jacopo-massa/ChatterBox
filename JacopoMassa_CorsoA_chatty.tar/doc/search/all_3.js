var searchData=
[
  ['chatty_2ec',['chatty.c',['../chatty_8c.html',1,'']]],
  ['chatty_2eh',['chatty.h',['../chatty_8h.html',1,'']]],
  ['chattystats',['chattyStats',['../chatty_8c.html#a9e4166354e886d074465ab1bb87ca0e2',1,'chatty.c']]],
  ['chooserequest',['chooseRequest',['../chatty_8c.html#a8a5fdcb8d0952a39ee1f687e0be4a868',1,'chooseRequest(void *fd):&#160;chatty.c'],['../chatty_8h.html#a8a5fdcb8d0952a39ee1f687e0be4a868',1,'chooseRequest(void *fd):&#160;chatty.c']]],
  ['cleanup',['cleanup',['../chatty_8c.html#a4b66d5e31b5dc18b314c8a68163263bd',1,'chatty.c']]],
  ['client_2ec',['client.c',['../client_8c.html',1,'']]],
  ['conf',['conf',['../chatty_8c.html#ab6773a27d1ebedf19031b06d5a397bd3',1,'chatty.c']]],
  ['conf_5fdestroy',['conf_destroy',['../utility_8c.html#a4116358234d3d7200b87e1287926e074',1,'conf_destroy(config_t *conf):&#160;utility.c'],['../utility_8h.html#a4116358234d3d7200b87e1287926e074',1,'conf_destroy(config_t *conf):&#160;utility.c']]],
  ['conf_5ffilepath',['conf_filepath',['../chatty_8c.html#afcb5093b169926cc8cbd9c289158d0c7',1,'chatty.c']]],
  ['config_2eh',['config.h',['../config_8h.html',1,'']]],
  ['config_5fs',['config_s',['../structconfig__s.html',1,'']]],
  ['config_5ft',['config_t',['../utility_8h.html#a63420d72830922875da1e3b20e15970b',1,'utility.h']]],
  ['connect_5fop',['CONNECT_OP',['../ops_8h.html#ac6fa1b34da8872e34c2936391332f44cab602ddf0795d3c4dc2fd0b4b957ba988',1,'ops.h']]],
  ['connections_2ec',['connections.c',['../connections_8c.html',1,'']]],
  ['connections_2eh',['connections.h',['../connections_8h.html',1,'']]],
  ['connectuser',['connectUser',['../chatty_8c.html#a9a271c959d6aab4ca90f4841992def66',1,'connectUser(long fd, char *nickname):&#160;chatty.c'],['../chatty_8h.html#a9a271c959d6aab4ca90f4841992def66',1,'connectUser(long fd, char *nickname):&#160;chatty.c']]],
  ['count',['count',['../structthreadpool__s.html#ad43c3812e6d13e0518d9f8b8f463ffcf',1,'threadpool_s']]],
  ['creategroup_5fop',['CREATEGROUP_OP',['../ops_8h.html#ac6fa1b34da8872e34c2936391332f44ca30840713ad9050c2d275b31ff8404313',1,'ops.h']]]
];
