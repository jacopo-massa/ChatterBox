var searchData=
[
  ['data',['data',['../structmessage__t.html#a4e61df2d2b915250fd442d19a80ca4ca',1,'message_t']]],
  ['deletequeue',['deleteQueue',['../queue_8c.html#a5a081e69542c667e437814b9df4a9f4e',1,'deleteQueue(queue_t *q):&#160;queue.c'],['../queue_8h.html#a5a081e69542c667e437814b9df4a9f4e',1,'deleteQueue(queue_t *q):&#160;queue.c']]],
  ['delgroup_5fop',['DELGROUP_OP',['../ops_8h.html#ac6fa1b34da8872e34c2936391332f44cab9abe0fa4dab90183a19f2f56dfe0d49',1,'ops.h']]],
  ['dirname',['DirName',['../structconfig__s.html#a68cc4e6509205eeddea8429d2c05f2fe',1,'config_s']]],
  ['disconnect_5fop',['DISCONNECT_OP',['../ops_8h.html#ac6fa1b34da8872e34c2936391332f44ca06d81ab3ef58420bbebac2c67dc901e2',1,'ops.h']]],
  ['divzero',['DIVZERO',['../utility_8h.html#a892c3eb482555c8964168afe961ef1ee',1,'utility.h']]],
  ['documentazione_20chattebox',['Documentazione Chattebox',['../index.html',1,'']]]
];
