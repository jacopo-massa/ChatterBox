var searchData=
[
  ['unix_5fpath_5fmax',['UNIX_PATH_MAX',['../connections_8h.html#a7baab2aa5bf8eb14b6128e0f16634837',1,'connections.h']]],
  ['unlock',['UNLOCK',['../utility_8h.html#a55c56e1eba14a6ea523ce0e47bf9208b',1,'utility.h']]]
];
