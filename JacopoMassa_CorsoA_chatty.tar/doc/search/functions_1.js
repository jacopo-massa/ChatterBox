var searchData=
[
  ['deletequeue',['deleteQueue',['../queue_8c.html#a5a081e69542c667e437814b9df4a9f4e',1,'deleteQueue(queue_t *q):&#160;queue.c'],['../queue_8h.html#a5a081e69542c667e437814b9df4a9f4e',1,'deleteQueue(queue_t *q):&#160;queue.c']]]
];
