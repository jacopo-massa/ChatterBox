var searchData=
[
  ['queuelength',['queueLength',['../queue_8c.html#adda68ee57046c6f7a96b6d7881111c18',1,'queueLength(queue_t *q):&#160;queue.c'],['../queue_8h.html#adda68ee57046c6f7a96b6d7881111c18',1,'queueLength(queue_t *q):&#160;queue.c']]],
  ['queuestatus',['queueStatus',['../queue_8c.html#ac979a596866467e11d837945058b3543',1,'queueStatus(FILE *stream, queue_t *q):&#160;queue.c'],['../queue_8h.html#ac979a596866467e11d837945058b3543',1,'queueStatus(FILE *stream, queue_t *q):&#160;queue.c']]]
];
