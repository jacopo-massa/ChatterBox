var searchData=
[
  ['node_5ft',['node_t',['../queue_8h.html#a12d2f5b8ea015d227017b464367fc335',1,'queue.h']]]
];
