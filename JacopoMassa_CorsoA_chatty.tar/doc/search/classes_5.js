var searchData=
[
  ['queue_5fs',['queue_s',['../structqueue__s.html',1,'']]]
];
