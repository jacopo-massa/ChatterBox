var searchData=
[
  ['getfile',['getFile',['../chatty_8c.html#a0539bd764b45ad55a0528c0561e0c664',1,'getFile(long fd, message_t msg):&#160;chatty.c'],['../chatty_8h.html#a0539bd764b45ad55a0528c0561e0c664',1,'getFile(long fd, message_t msg):&#160;chatty.c']]],
  ['getprevmsgs',['getPrevMSGS',['../chatty_8c.html#a2cfeac572e621db4689289676b5030ba',1,'getPrevMSGS(long fd, message_t msg):&#160;chatty.c'],['../chatty_8h.html#a2cfeac572e621db4689289676b5030ba',1,'getPrevMSGS(long fd, message_t msg):&#160;chatty.c']]]
];
