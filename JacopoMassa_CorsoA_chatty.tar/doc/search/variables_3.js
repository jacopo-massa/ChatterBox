var searchData=
[
  ['data',['data',['../structmessage__t.html#a4e61df2d2b915250fd442d19a80ca4ca',1,'message_t']]],
  ['dirname',['DirName',['../structconfig__s.html#a68cc4e6509205eeddea8429d2c05f2fe',1,'config_s']]]
];
