var searchData=
[
  ['op_5fend',['OP_END',['../ops_8h.html#ac6fa1b34da8872e34c2936391332f44ca010acee11f1e0ca0026e20c2f36bfdb7',1,'ops.h']]],
  ['op_5ffail',['OP_FAIL',['../ops_8h.html#ac6fa1b34da8872e34c2936391332f44cadad4289276b97b650558ce66d141d648',1,'ops.h']]],
  ['op_5fmsg_5ftoolong',['OP_MSG_TOOLONG',['../ops_8h.html#ac6fa1b34da8872e34c2936391332f44ca020f2a80f521804e41b46c6f994ec72f',1,'ops.h']]],
  ['op_5fnick_5falready',['OP_NICK_ALREADY',['../ops_8h.html#ac6fa1b34da8872e34c2936391332f44ca81c2903af74ab2d9f41295295ebdf818',1,'ops.h']]],
  ['op_5fnick_5funknown',['OP_NICK_UNKNOWN',['../ops_8h.html#ac6fa1b34da8872e34c2936391332f44ca460bac3ab18774fdad96a60256f5f58b',1,'ops.h']]],
  ['op_5fno_5fsuch_5ffile',['OP_NO_SUCH_FILE',['../ops_8h.html#ac6fa1b34da8872e34c2936391332f44ca1f7fb97bf4bf19858a8805313eca2ae2',1,'ops.h']]],
  ['op_5fok',['OP_OK',['../ops_8h.html#ac6fa1b34da8872e34c2936391332f44cacc156be86a1cb4bfc0e21d8c72e4971c',1,'ops.h']]]
];
