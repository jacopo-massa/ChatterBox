var searchData=
[
  ['chooserequest',['chooseRequest',['../chatty_8c.html#a8a5fdcb8d0952a39ee1f687e0be4a868',1,'chooseRequest(void *fd):&#160;chatty.c'],['../chatty_8h.html#a8a5fdcb8d0952a39ee1f687e0be4a868',1,'chooseRequest(void *fd):&#160;chatty.c']]],
  ['cleanup',['cleanup',['../chatty_8c.html#a4b66d5e31b5dc18b314c8a68163263bd',1,'chatty.c']]],
  ['conf_5fdestroy',['conf_destroy',['../utility_8c.html#a4116358234d3d7200b87e1287926e074',1,'conf_destroy(config_t *conf):&#160;utility.c'],['../utility_8h.html#a4116358234d3d7200b87e1287926e074',1,'conf_destroy(config_t *conf):&#160;utility.c']]],
  ['connectuser',['connectUser',['../chatty_8c.html#a9a271c959d6aab4ca90f4841992def66',1,'connectUser(long fd, char *nickname):&#160;chatty.c'],['../chatty_8h.html#a9a271c959d6aab4ca90f4841992def66',1,'connectUser(long fd, char *nickname):&#160;chatty.c']]]
];
