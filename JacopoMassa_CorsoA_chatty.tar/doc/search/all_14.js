var searchData=
[
  ['unix_5fpath_5fmax',['UNIX_PATH_MAX',['../connections_8h.html#a7baab2aa5bf8eb14b6128e0f16634837',1,'connections.h']]],
  ['unixpath',['UnixPath',['../structconfig__s.html#ab13f2c10dc85ac86a157ab17f7559e9f',1,'config_s']]],
  ['unlock',['UNLOCK',['../utility_8h.html#a55c56e1eba14a6ea523ce0e47bf9208b',1,'utility.h']]],
  ['unregister_5fop',['UNREGISTER_OP',['../ops_8h.html#ac6fa1b34da8872e34c2936391332f44cabc2ab44946aad99a4cda3f0e4abb5b5a',1,'ops.h']]],
  ['unregisteruser',['unregisterUser',['../chatty_8c.html#a00541c1f40f3e1eea3dd303e914a82b2',1,'unregisterUser(long fd, char *nickname):&#160;chatty.c'],['../chatty_8h.html#a00541c1f40f3e1eea3dd303e914a82b2',1,'unregisterUser(long fd, char *nickname):&#160;chatty.c']]],
  ['users',['users',['../chatty_8c.html#acb748f6c78847d13af1bf7ee34b66b66',1,'chatty.c']]],
  ['usrlist',['usrList',['../chatty_8c.html#a2d6a679c0d97507fc23aad02e9fb8b3b',1,'usrList(long fd, char *sender):&#160;chatty.c'],['../chatty_8h.html#a2d6a679c0d97507fc23aad02e9fb8b3b',1,'usrList(long fd, char *sender):&#160;chatty.c']]],
  ['usrlist_5fop',['USRLIST_OP',['../ops_8h.html#ac6fa1b34da8872e34c2936391332f44ca76c5f8cf5dd046fbfe3f0b6a7bce8e90',1,'ops.h']]],
  ['utility_2ec',['utility.c',['../utility_8c.html',1,'']]],
  ['utility_2eh',['utility.h',['../utility_8h.html',1,'']]]
];
