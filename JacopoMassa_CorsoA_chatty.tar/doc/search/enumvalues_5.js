var searchData=
[
  ['immediate_5fshutdown',['immediate_shutdown',['../threadpool_8h.html#a57df7f50d2fcada8b393c358d5a02288a876f350433b986fed4294a9f88226de0',1,'threadpool.h']]]
];
