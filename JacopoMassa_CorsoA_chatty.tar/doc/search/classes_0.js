var searchData=
[
  ['config_5fs',['config_s',['../structconfig__s.html',1,'']]]
];
