var searchData=
[
  ['queue_5ft',['queue_t',['../queue_8h.html#a2f69bc2858947e9964e4aa291b78c264',1,'queue.h']]]
];
