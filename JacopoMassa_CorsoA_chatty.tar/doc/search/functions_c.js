var searchData=
[
  ['unregisteruser',['unregisterUser',['../chatty_8c.html#a00541c1f40f3e1eea3dd303e914a82b2',1,'unregisterUser(long fd, char *nickname):&#160;chatty.c'],['../chatty_8h.html#a00541c1f40f3e1eea3dd303e914a82b2',1,'unregisterUser(long fd, char *nickname):&#160;chatty.c']]],
  ['usrlist',['usrList',['../chatty_8c.html#a2d6a679c0d97507fc23aad02e9fb8b3b',1,'usrList(long fd, char *sender):&#160;chatty.c'],['../chatty_8h.html#a2d6a679c0d97507fc23aad02e9fb8b3b',1,'usrList(long fd, char *sender):&#160;chatty.c']]]
];
