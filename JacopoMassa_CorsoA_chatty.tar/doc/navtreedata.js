/*
@ @licstart  The following is the entire license notice for the
JavaScript code in this file.

Copyright (C) 1997-2017 by Dimitri van Heesch

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

@licend  The above is the entire license notice
for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "ChatterBox", "index.html", [
    [ "Introduzione", "index.html#intro_sec", null ],
    [ "Operazioni", "index.html#op_sec", null ],
    [ "Classi", "annotated.html", [
      [ "Elenco dei tipi composti", "annotated.html", "annotated_dup" ],
      [ "Indice dei tipi composti", "classes.html", null ],
      [ "Membri dei composti", "functions.html", [
        [ "Tutto", "functions.html", null ],
        [ "Variabili", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "File", "files.html", [
      [ "Elenco dei file", "files.html", "files_dup" ],
      [ "Elementi dei file", "globals.html", [
        [ "Tutto", "globals.html", null ],
        [ "Funzioni", "globals_func.html", null ],
        [ "Variabili", "globals_vars.html", null ],
        [ "Ridefinizioni di tipo (typedef)", "globals_type.html", null ],
        [ "Tipi enumerati (enum)", "globals_enum.html", null ],
        [ "Valori del tipo enumerato", "globals_eval.html", null ],
        [ "Definizioni", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_c_make_c_compiler_id_8c.html",
"structthreadpool__s.html#a2f46f7caccb34afc81a82aa2d61fc1ba"
];

var SYNCONMSG = 'cliccare per disabilitare la sincronizzazione del pannello';
var SYNCOFFMSG = 'cliccare per abilitare la sincronizzazione del pannello';