var structmessage__data__hdr__t =
[
    [ "len", "structmessage__data__hdr__t.html#a4b5503aa5aa13262ce9a702f61176579", null ],
    [ "receiver", "structmessage__data__hdr__t.html#af6c7df81f506cf337ac5e7948fc3a665", null ]
];