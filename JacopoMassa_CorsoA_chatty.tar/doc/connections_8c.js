var connections_8c =
[
    [ "_POSIX_C_SOURCE", "connections_8c.html#a3024ccd4a9af5109d24e6c57565d74a1", null ],
    [ "openConnection", "connections_8c.html#a93ad31c416b2e2055827e5f684e89daf", null ],
    [ "readData", "connections_8c.html#acf5cb8379636265d11a008d6aa94dc30", null ],
    [ "readHeader", "connections_8c.html#a2a15cc3debfd6700ea0f40a198c55c85", null ],
    [ "readMsg", "connections_8c.html#a2fc6b845d44636fb241a848e58c83420", null ],
    [ "sendData", "connections_8c.html#a7812cf59eeeaa63ce7d7b9ce93125462", null ],
    [ "sendHeader", "connections_8c.html#a1a3f1d447f26575379802386e4cb1587", null ],
    [ "sendRequest", "connections_8c.html#a3c23eb25de2ae8b5216eb6dd847521c0", null ]
];