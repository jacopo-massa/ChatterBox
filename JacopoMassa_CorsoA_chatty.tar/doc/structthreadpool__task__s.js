var structthreadpool__task__s =
[
    [ "arg", "structthreadpool__task__s.html#a8ac882b65b8a472148b7e13acd24d814", null ],
    [ "function", "structthreadpool__task__s.html#a65cb8b324fb93e36c0503738cb3f779e", null ]
];