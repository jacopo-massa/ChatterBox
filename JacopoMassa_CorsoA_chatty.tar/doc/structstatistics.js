var structstatistics =
[
    [ "ndelivered", "structstatistics.html#ac09e24f0d5aa3c8255f734ff040f998e", null ],
    [ "nerrors", "structstatistics.html#a893b0a0d9f1fe9a6b9cf61d1f020f265", null ],
    [ "nfiledelivered", "structstatistics.html#a87279336813cee36c18e6299606b1dd8", null ],
    [ "nfilenotdelivered", "structstatistics.html#a82667eb0d0b1a45917193e9e1d6d463a", null ],
    [ "nnotdelivered", "structstatistics.html#a7d8cbe9fc73479a941714316b48ffd48", null ],
    [ "nonline", "structstatistics.html#afe88b6c92f8cc91e152216167f2b6046", null ],
    [ "nusers", "structstatistics.html#a390a45ca74cf019667fcf33848a33d13", null ]
];