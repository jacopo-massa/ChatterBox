var structmessage__hdr__t =
[
    [ "op", "structmessage__hdr__t.html#ab7f4eacc8e900cca79b63ddfb02d67fd", null ],
    [ "sender", "structmessage__hdr__t.html#a53c6bc32851e00a0fe818315d5029f43", null ]
];