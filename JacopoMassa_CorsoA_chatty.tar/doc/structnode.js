var structnode =
[
    [ "msg", "structnode.html#a111b8d2e6b710a27be13f2cb62a641e4", null ],
    [ "next", "structnode.html#aa3e8aa83f864292b5a01210f4453fcc0", null ]
];