var structqueue =
[
    [ "head", "structqueue.html#a74104abb8cf9eb0415c302f7dec45781", null ],
    [ "qcurr", "structqueue.html#a63c6ba5190f45c49cceee3d961d3925b", null ],
    [ "qlen", "structqueue.html#a2efaffff8623d30212235addd38d918d", null ],
    [ "qmax", "structqueue.html#a76537ef9d18c5be1169625a2d96bac76", null ],
    [ "tail", "structqueue.html#aaca425bed758b339855fcd4cc040f593", null ]
];